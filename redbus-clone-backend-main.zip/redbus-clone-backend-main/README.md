Backend for redbus-clone
