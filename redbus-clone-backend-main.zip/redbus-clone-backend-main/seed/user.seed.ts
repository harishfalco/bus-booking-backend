export const createUser = {
  firstName: "harish",
  lastName: "Kumar",
  email: "harish.19@gamil.com",
  password: "Harish@07",
  type: "operator",
};

export const userOperator = {
  firstName: "harish",
  lastName: "Kumar",
  email: "harish@gamil.com",
  password: "Harish@07",
  type: "operator",
};
export const userCustomer = {
  firstName: "harish",
  lastName: "Kumar",
  email: "harish.1@gamil.com",
  password: "Harish@07",
  type: "customer",
};

export const createCustomer = {
  firstName: "harish",
  lastName: "kumar",
  email: "harish.2@gamil.com",
  password: "Harish@07",
  type: "customer",
};

export const busOperator = {
  firstName: "harish",
  lastName: "Kumar",
  email: "haris.12h@gamil.com",
  password: "Harish@07",
  type: "operator",
};
export const createInvalidUser = {
  firstName: "harish",
  lastname: "kumar",
  email: "harish.1@gamil.com",
  password: "Harish@07",
};

export const validLogin = {
  email: "harish@gamil.com",
  password: "Harish@07",
};
export const inValidLogin = {
  email: "harish@gamil.com",
  password: "harish",
};
