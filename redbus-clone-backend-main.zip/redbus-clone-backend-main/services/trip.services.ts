import { ITrip } from "./../interfaces";
import { updateTrip, findTripBasedOnFilters } from "../dbLayer/trip.db";
import {
  ISeat,
  ITripFilters,
  ISeatsGenerationInfo,
  IUpdateInfo,
} from "../interfaces";
import { Trip } from "../models/trip.model";
import { getStartDateEndDate } from "./bus.services";

/**
 * * Generate seats based on Information provided while creating trip
 * @param seatInfo Contains information to generate seats
 * @returns Returns an array of setas
 */
export const generateSeats = (seatInfo: ISeatsGenerationInfo) => {
  const {
    sleeperPrice,
    seaterPrice,
    upperPrice,
    totalSleeper,
    totalSeater,
    totalUpper,
  } = seatInfo;

  const seats: ISeat[] = [];
  if (totalSeater === 0 && totalSleeper && totalUpper) {
    for (let i = 0; i < totalSleeper; i++) {
      seats.push({
        seatNo: `sle.${i}`,
        type: "sleeper",
        price: sleeperPrice,
      });
    }
    for (let i = 0; i < totalUpper; i++) {
      seats.push({
        seatNo: `upp.${i}`,
        type: "upper",
        price: upperPrice,
      });
    }
    return seats;
  }

  if (totalSleeper && totalUpper && totalSeater) {
    for (let i = 0; i < totalSleeper; i++) {
      seats.push({
        seatNo: `sle.${i}`,
        type: "sleeper",
        price: sleeperPrice,
      });
    }

    for (let i = 0; i < totalSeater; i++) {
      seats.push({
        seatNo: `sea.${i}`,
        type: "seater",
        price: seaterPrice,
      });
    }

    for (let i = 0; i < totalUpper; i++) {
      seats.push({
        seatNo: `upp.${i}`,
        type: "upper",
        price: upperPrice,
      });
    }
    return seats;
  }

  if (totalSeater && !totalUpper && !totalSleeper) {
    for (let i = 0; i < totalSeater; i++) {
      seats.push({
        seatNo: `sea.${i}`,
        type: "seater",
        price: seaterPrice,
      });
    }
    return seats;
  }
  return seats;
};

/**
 * * Updates new values in trip based on trip id
 * @param id Id of Trip document
 * @param newValues Values to update in trip document
 * @returns updated trip object
 */
export const updateTripWithNewValues = async (
  id: string,
  newValues: IUpdateInfo
) => {
  const {
    sleeperPrice,
    seaterPrice,
    upperPrice,
    totalSleeper,
    totalSeater,
    totalUpper,
  } = newValues;
  const seats = generateSeats({
    sleeperPrice,
    seaterPrice,
    upperPrice,
    totalSleeper,
    totalSeater,
    totalUpper,
  });
  const availableSeats = seats.map((seat) => seat.seatNo);
  const valuesToUpdate: IUpdateInfo = Object.assign({}, newValues, {
    seat: seats,
    availableSeats,
  });
  const tripId = id;
  const updatedTrip = await updateTrip(tripId, valuesToUpdate);
  return updatedTrip;
};
/**
 * * Fetches Trips from database based on given filters
 * @param filters Based on these filters trips are fetched from database
 * @returns Trip array that match the filters
 */
export const getTripsBasedOnFilters = async (filters: ITripFilters) => {
  const { startLocation, endLocation, dateOfTravel } = filters;
  let { isAc, isSleeper } = filters;
  isSleeper = isSleeper.toLowerCase();
  isAc = isAc.toLowerCase();
  const typeQuery: { [key: string]: boolean } = {};
  if (!(isAc == null)) typeQuery["isAc"] = isAc === "true";
  if (!(isSleeper == null)) typeQuery["isSleeper"] = isSleeper === "true";
  const { startDate, endDate } = getStartDateEndDate(dateOfTravel);
  const trips = await Trip.find({
    from: startLocation,
    to: endLocation,
    startDate: {
      $gte: startDate,
      $lte: endDate,
    },
    ...typeQuery,
  });
  return trips;
};

export const getSeats = async (trip: ITrip) => {
  const seatArray = [];
  for (const seat of trip.seat) {
    const responseSeat = {
      seatNo: seat.seatNo,
      type: seat.type,
      price: seat.price,
      booked: false,
    };
    if (!trip.availableSeats?.includes(seat.seatNo)) responseSeat.booked = true;
    seatArray.push(responseSeat);
  }
  return seatArray;
};
